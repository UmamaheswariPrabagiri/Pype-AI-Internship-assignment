import { useRouter } from 'next/router';
import axios from 'axios';

const Details = ({ weatherData }) => {
  const router = useRouter();
  const { city } = router.query;

  return (
    <div>
      <h2>Weather Details for {city}</h2>
      <p>Temperature: {weatherData.main.temp}°C</p>
      <p>Humidity: {weatherData.main.humidity}%</p>
      <p>Wind Speed: {weatherData.wind.speed} m/s</p>
      <p>Description: {weatherData.weather[0].description}</p>
    </div>
  );
};

export async function getServerSideProps(context) {
  const { city } = context.params;
  const apiKey = 'YOUR_API_KEY';
  const apiUrl = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`;

  try {
    const response = await axios.get(apiUrl);
    const weatherData = response.data;
    return {
      props: {
        weatherData,
      },
    };
  } catch (error) {
    console.error('Error fetching weather data:', error.message);
    return {
      props: {},
    };
  }
}

export default Details;

