import Link from 'next/link';

const Home = () => {
  return (
    <div>
      <h1>Welcome to the Weather App</h1>
      <Link href="/search">
        <a>Search Weather</a>
      </Link>
    </div>
  );
};

export default Home;

