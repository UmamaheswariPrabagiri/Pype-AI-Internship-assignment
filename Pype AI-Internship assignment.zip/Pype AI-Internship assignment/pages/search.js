import { useState } from 'react';
import { useRouter } from 'next/router';

const Search = () => {
  const [city, setCity] = useState('');
  const router = useRouter();

  const handleSubmit = (e) => {
    e.preventDefault();
    router.push(`/details/${city}`);
  };

  return (
    <div>
      <h2>Search Weather</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          value={city}
          onChange={(e) => setCity(e.target.value)}
          placeholder="Enter city"
        />
        <button type="submit">Search</button>
      </form>
    </div>
  );
};

export default Search;

